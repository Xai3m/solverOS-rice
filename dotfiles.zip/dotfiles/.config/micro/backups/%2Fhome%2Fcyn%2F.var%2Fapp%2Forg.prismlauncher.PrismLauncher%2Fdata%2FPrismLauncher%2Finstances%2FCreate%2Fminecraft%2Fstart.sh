java -Xmx16G -jar /home/cyn/.var/app/org.prismlauncher.PrismLauncher/data/PrismLauncher/instances/Create/minecraft/neoforge-21.1.265-installer.jar
