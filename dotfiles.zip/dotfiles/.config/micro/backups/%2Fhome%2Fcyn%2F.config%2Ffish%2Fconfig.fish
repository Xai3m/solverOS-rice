source /usr/share/cachyos-fish-config/cachyos-config.fish

allias=""
# overwrite greeting
# potentially disabling fastfetch
#function fish_greeting
#    # smth smth
#end
