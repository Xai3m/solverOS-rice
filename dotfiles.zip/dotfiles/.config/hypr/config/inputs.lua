-- Input configuration

hl.config({
    input = {
        sensitivity = -0.86,
        accel_profile = "flat",
        numlock_by_default = true,
        kb_layout = "us,cz",
    	kb_options = "grp:alt_space_toggle",
    }
})
    -- Uncomment the section below to enable software cursors; this can help with cursor display or behavior issues
hl.config({    cursor = { no_hardware_cursors = 1},
})

hl.gesture({ fingers = 4, direction = "horizontal", action = "workspace" })
hl.gesture({ fingers = 3, direction = "down",       action = "close" })
hl.gesture({ fingers = 3, direction = "up",         action = "fullscreen" })
hl.gesture({ fingers = 3, direction = "left",       action = "float" })
