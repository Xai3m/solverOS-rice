-- Cachy colors

CACHYLGREEN = "rgba(ffe600ff)"
CACHYMGREEN = "rgba(ffd600ff)"
CACHYDGREEN = "rgba(ffd600ff)"
CACHYLBLUE  = "rgba(ffd600ff)"
CACHYMBLUE  = "rgba(ffd600ff)"
CACHYDBLUE  = "rgba(ffd600ff)"
CACHYWHITE  = "rgba(ffffffff)"
CACHYGREY   = "rgba(ddddddff)"
CACHYGRAY   = "rgba(ffd600ff)"
