function stab --wraps='mpv --no-video --no-terminal ~/stab.opus & kill --all -9' --description 'alias stab=mpv --no-video --no-terminal ~/Music/Solver/stab.opus & kill --all -9'
    mpv --no-video --no-terminal ~/stab.opus & kill --all -9 $argv
end
