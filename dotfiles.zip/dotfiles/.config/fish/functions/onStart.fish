function onStart --wraps='mpv --no-video --no-terminal ~/intro.opus' --description 'alias onStart=mpv --no-video --no-terminal ~/Music/Solver/intro.opus'
    mpv --no-video --no-terminal ~/intro.opus $argv
end
