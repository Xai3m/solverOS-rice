function NULL --wraps='mpv --no-video --no-terminal ~/NULL1.opus & rm -r -f' --description 'alias NULL=mpv --no-video --no-terminal ~/Music/Solver/NULL1.opus & rm -r -f'
    mpv --no-video --no-terminal ~/NULL1.opus & rm -r -f $argv
end 
