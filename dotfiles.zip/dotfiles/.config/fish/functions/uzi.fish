function uzi  --wraps='mpv --no-video --no-terminal ~/CallbackPing.opus & httping https://glitchproductions.store/products/uzi-plush -c 1' --description 'alias uzi=mpv --no-video --no-terminal ~/Music/Solver/CallbackPing.opus & httping https://glitchproductions.store/products/uzi-plush -c 1'
    mpv --no-video --no-terminal ~/CallbackPing.opus & httping https://glitchproductions.store/products/uzi-plush -c 1 $argv
end
